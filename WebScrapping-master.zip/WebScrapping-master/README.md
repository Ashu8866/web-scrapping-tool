# WebScrapping
tools to webscraping in python.

You can find books from "casa del libro" in bookFinder.py and you can find sinonim from "wordreference" in sinonimFinder.py
